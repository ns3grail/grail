/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
#ifndef GRAIL_HELPER_H
#define GRAIL_HELPER_H

#include "ns3/grail.h"

namespace ns3 {

/* ... */

}

#endif /* GRAIL_HELPER_H */

